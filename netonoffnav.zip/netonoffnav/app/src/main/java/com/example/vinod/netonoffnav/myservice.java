package com.example.vinod.netonoffnav;
import android.app.NotificationManager;
import android.app.Service;
import android.support.annotation.Nullable;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;

import android.support.design.widget.Snackbar;

import android.util.Log;

import android.widget.Toast;

public class myservice  extends Service {

    static final String CONNECTIVITY_CHANGE_ACTION = "android.net.conn.CONNECTIVITY_CHANGE";
    NotificationManager manager;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public int onStartCommand(Intent intent, final int flags, final int startId) {
        // Let it continue running until it is stopped.
        Snackbar.make(MainActivity.mContext ,"Started",Snackbar.LENGTH_LONG).show();
//        Toast.makeText(this, " Started", Toast.LENGTH_LONG).show();
        final IntentFilter filter = new IntentFilter();
        filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        final BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (CONNECTIVITY_CHANGE_ACTION.equals(action)) {
                    //checking internet connection
                    if (!ConnectionHelper.isConnectedOrConnecting(context)) {
                        if (context != null) {
                            boolean show = false;
                            if (ConnectionHelper.lastNoConnectionTs == -1) {//first time
                                show = true;
                                ConnectionHelper.lastNoConnectionTs = System.currentTimeMillis();
                                //  Toast.makeText(context, "conntioon lost", Toast.LENGTH_LONG).show();
                            } else {
                                if (System.currentTimeMillis() - ConnectionHelper.lastNoConnectionTs > 1000) {
                                    show = true;
                                    ConnectionHelper.lastNoConnectionTs = System.currentTimeMillis();
                                }
                            }
                            if (show && ConnectionHelper.isOnline) {
                                ConnectionHelper.isOnline = false;
                                Log.i("NETWORK123", "Connection lost");
                                Snackbar.make(MainActivity.mContext ,"internet connection lost", Snackbar.LENGTH_LONG).show();
                               //  Toast.makeText(context, "internet connection lost", Toast.LENGTH_LONG).show();
                            }
                        }
                    } else {
                        Log.i("NETWORK123", "Connected");
                        showNotifications("APP", "It is working");
                        //Toast.makeText(context, "internet connected ", Toast.LENGTH_LONG).show();
                        Snackbar.make(MainActivity.mContext ,"internet connected", Snackbar.LENGTH_LONG).show();
                        // Perform your actions here
                        ConnectionHelper.isOnline = true;
                    }
                }
            }
            private void showNotifications(String app, String it_is_working) {
            }
            };
        registerReceiver(receiver, filter);
        return START_STICKY;
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "Service Destroyed", Toast.LENGTH_LONG).show();
    }
}
